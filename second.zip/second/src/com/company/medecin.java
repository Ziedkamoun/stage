package com.company;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class medecin {
    private static List<medecin> l;
    private String nom;
    private String prenom;
    private String specialite;
    private String adresse;



    public void setName(String name) {
        this.nom = name;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }
    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }


    public String getNom() {
        return nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getSpecialite() {
        return specialite;
    }
    public medecin(String nom,String prenom,String specialite,String adresse)
    {
        this.nom=nom;
        this.prenom=prenom;
        this.specialite=specialite;
        this.adresse=adresse;
    }
public void existe(List<medecin> l,String nom)
{


    for (medecin la : l)
    {
        if (la.getNom().equals(nom))
        {
            System.out.print(" "+la.getNom()+" "+la.getPrenom()+" "+la.getSpecialite()+la.getAdresse());
        }
    }
}

}
