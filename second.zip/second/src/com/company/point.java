package com.company;

public class point {
    int x;
    int y;

    point (int x,int y)
    {
        this.x=x;
        this.y=y;
    }
    point(){
        this.x=0;
        this.y=0;
    }
    void surdeux(){
        this.x=this.x/2;
        this.y=this.y/2;
    }
    void print(){
        System.out.print(this.x);
        System.out.print(this.y);
    }
}
