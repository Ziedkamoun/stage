package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);
        ArrayList<medecin> lista = new ArrayList<medecin>();


        medecin m = new medecin("ali", "salah", "sasa", "dazd");
        medecin m2 = new medecin("salah", "aziz", "bebe", "tunis");
        medecin m3 = new medecin("selim", "wael", "homme", "zahra");
        medecin m4 = new medecin("olfa", "wael", "femme", "kram");
        medecin m5 = new medecin("karima", "wael", "pediatre", "sfax");
        medecin m6 = new medecin("racem", "wael", "dentise", "sousse");
        medecin m7 = new medecin("wiem", "wael", "pediatre", "benarous");
        medecin m8 = new medecin("sondes", "wael", "chirugien", "kef");
        lista.add(m);
        lista.add(m2);
        lista.add(m3);
        lista.add(m4);
        lista.add(m5);
        lista.add(m6);
        lista.add(m7);
        lista.add(m8);
        System.out.println("Enter a Noun");
        String a = s.next();

        Iterator<medecin> iterator = lista.iterator();
        while (iterator.hasNext()) {

            medecin med = iterator.next();
            if (med.getNom().equals(a)) {
                System.out.print(" " + med.getNom() + " " + med.getPrenom() + " " + med.getSpecialite() + " " + med.getAdresse());
            }
        }
    }
}






